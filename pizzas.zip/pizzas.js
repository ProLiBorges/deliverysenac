
let cardapio = [
    {
        foto: "imgs/Pizza5.jpg",
        nome: "Calabresa",
        ingredientes: ["Calabresa", "Cebola", "Muçarela"],
        valor: 35.00
    },
    {
        foto: "imgs/Pizza2.jpg",
        nome: "Muçarela",
        ingredientes: ["Beringela", "Cebola", "Muçarela"],
        valor: 40.00
    },
    {
        foto: "imgs/Pizza3.jpg",
        nome: "Mista de Vegetais",
        ingredientes: ["Beringela", "Abobrinha", "Pimentão", "Cebola", "Muçarela"],
        valor: 40.00
    },
    {
        foto: "imgs/FCatupiry.jpg",
        nome: "Frango com Catupiry",
        ingredientes: ["Frango", "Catupiry", "Muçarela"],
        valor: 40.00
    }
];